// MR DEVIL BOT - connection handler (no external contact, no auto group/inbox)
async function ensureRDXConnection(api) {
  return true;
}

module.exports = { ensureRDXConnection };
